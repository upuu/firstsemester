<!DOCTYPE html>
<html lang="en">
<head>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/gh/lipis/flag-icons@6.11.0/css/flag-icons.min.css"
/>
<title>Currency Converter</title>
</head>
<body>

<fieldset>
    <form action = "currency.php" method="post" class = "form">
        <label for="">amount of initial currency</label>
        <input type="number" step = "0.01" name="amount" id = "amount" placeholder = "enter amount of currency">(only numbers accepted)
        <br>
        <p> select initial currency </p>
            <input type ="radio" name = "currency" value = "CAD"><i class= "fi fi-ca"></i>CAD
            <input type ="radio" name = "currency" value = "USD"><i class= "fi fi-us"></i>USD
            <input type ="radio" name = "currency" value = "EUR"><i class= "fi fi-eu"></i>EUR
            <input type ="radio" name = "currency" value = "GBP"><i class = "fi fi-gb"></i>GBP
            <input type ="radio" name = "currency" value = "CHY"><i class = "fi fi-cn"></i>CHY
        <br>
        <p> select currency to convert to </p>
            <input type ="radio" name = "currencyTo" value = "CAD"><i class= "fi fi-ca"></i>CAD
            <input type ="radio" name = "currencyTo" value = "USD"><i class= "fi fi-us"></i>USD
            <input type ="radio" name = "currencyTo" value = "EUR"><i class= "fi fi-eu"></i>EUR
            <input type ="radio" name = "currencyTo" value = "GBP"><i class = "fi fi-gb"></i>GBP
            <input type ="radio" name = "currencyTo" value = "CHY"><i class = "fi fi-cn"></i>CHY
        <br>
        <br>
        <br>
        <input type="submit" name="submit" value="Calculate value">
        <br>
        <h2>
        <?php
        if(isset($_POST["amount"]) AND $_POST["amount"] == "0") {
            echo "zero of anything is zero.";
            return;
        }
        
        
        if(isset($_POST["amount"]) AND isset($_POST["currency"]) AND isset($_POST["currencyTo"])) {

            $amount = $_POST["amount"];
            $currency = $_POST["currency"];
            $currencyTo = $_POST["currencyTo"];
            $convrate = 0;

        
            switch($currency) {
        
                case "CAD":
                    switch($currencyTo){
                        case "CAD":
                            $convrate = 1;
                            $flagog = "<i class= 'fi fi-ca'></i>";
                            $flagnew = "<i class= 'fi fi-ca'></i>";
                            break;
                        case "GBP":
                            $convrate = .6;
                            $flagog = "<i class= 'fi fi-ca'></i>";
                            $flagnew = "<i class = 'fi fi-gb'></i>";
                            break;
                        case "USD":
                            $convrate = .72;
                            $flagog = "<i class= 'fi fi-ca'></i>";
                            $flagnew = "<i class = 'fi fi-us'></i>";
                            break;
                        case "EUR":
                            $convrate = .68;
                            $flagog = "<i class= 'fi fi-ca'></i>";
                            $flagnew ="<i class= 'fi fi-eu'></i>";
                            break;
                        case "CHY":
                            $convrate = 5.3;
                            $flagog = "<i class= 'fi fi-ca'></i>";
                            $flagnew = "<i class= 'fi fi-cn'></i>";
                            break;
        
                    }
                break;
                case "USD":
                    switch($currencyTo){
                        case "CAD":
                            $convrate = 1.4;
                            $flagog = "<i class= 'fi fi-us'></i>";
                            $flagnew = "<i class= 'fi fi-ca'></i>";
                            break;
                        case "USD":
                            $convrate = 1;
                            $flagog = "<i class= 'fi fi-us'></i>";
                            $flagnew = "<i class = 'fi fi-us'></i>";
                            break;
                        case "GBP":
                            $convrate = .8;
                            $flagog = "<i class= 'fi fi-us'></i>";
                            $flagnew = "<i class = 'fi fi-gb'></i>";
                            break;
                        case "EUR":
                            $convrate = .95;
                            $flagog = "<i class= 'fi fi-us'></i>";
                            $flagnew ="<i class= 'fi fi-eu'></i>";
                            break;
                        case "CHY":
                            $convrate = 7.3;
                            $flagog = "<i class= 'fi fi-us'></i>";
                            $flagnew = "<i class= 'fi fi-cn'></i>";
                            break;
        
                    }
                break;
                case "EUR":
                    switch($currencyTo){
                        case "CAD":
                            $convrate = 1.47;
                            $flagog = "<i class= 'fi fi-eu'></i>";
                            $flagnew = "<i class= 'fi fi-ca'></i>";
                            break;
                        case "USD":
                            $convrate = 1.1;
                            $flagog = "<i class= 'fi fi-eu'></i>";
                            $flagnew = "<i class = 'fi fi-us'></i>";
                            break;
                        case "EUR":
                            $convrate = 1;
                            $flagog = "<i class= 'fi fi-eu'></i>";
                            $flagnew ="<i class= 'fi fi-eu'></i>";
                            break;
                        case "GBP":
                            $convrate = .9;
                            $flagog = "<i class= 'fi fi-eu'></i>";
                            $flagnew = "<i class = 'fi fi-gb'></i>";
                            break;
                        case "CHY":
                            $convrate = 7.8;
                            $flagog = "<i class= 'fi fi-eu'></i>";
                            $flagnew = "<i class= 'fi fi-cn'></i>";
                            break;
                    }
                break;
                case "GBP":
                    switch($currencyTo){
                        case "CAD":
                            $convrate = 1.7;
                            $flagog = "<i class = 'fi fi-gb'></i>";
                            $flagnew = "<i class= 'fi fi-ca'></i>";
                            break;
                        case "USD":
                            $convrate = 1.2;
                            $flagog = "<i class = 'fi fi-gb'></i>";
                            $flagnew = "<i class = 'fi fi-us'></i>";
                            break;
                        case "EUR":
                            $convrate = 1.1;
                            $flagog = "<i class = 'fi fi-gb'></i>";
                            $flagnew ="<i class= 'fi fi-eu'></i>";
                            break;
                        case "GBP":
                            $convrate = 1;
                            $flagog = "<i class = 'fi fi-gb'></i>";
                            $flagnew = "<i class = 'fi fi-gb'></i>";
                            break;
                        case "CHY":
                            $convrate = 8.8;
                            $flagog = "<i class = 'fi fi-gb'></i>";
                            $flagnew = "<i class= 'fi fi-cn'></i>";
                            break;
                    
                    }
                break;
                case "CHY":
                    switch($currencyTo){
                        case "CAD":
                            $convrate = .2;
                            $flagog = "<i class= 'fi fi-cn'></i>";
                            $flagnew = "<i class= 'fi fi-ca'></i>";
                            break;
                        case "USD":
                            $convrate = .15;
                            $flagog = "<i class= 'fi fi-cn'></i>";
                            $flagnew = "<i class = 'fi fi-us'></i>";
                            break;
                        case "EUR":
                            $convrate = .13;
                            $flagog = "<i class= 'fi fi-cn'></i>";
                            $flagnew ="<i class= 'fi fi-eu'></i>";
                            break;
                        case "GBP":
                            $convrate = .1;
                            $flagog = "<i class= 'fi fi-cn'></i>";
                            $flagnew = "<i class = 'fi fi-gb'></i>";
                            break;
                        case "CHY":
                            $convrate = 1;
                            $flagog = "<i class= 'fi fi-cn'></i>";
                            $flagnew = "<i class= 'fi fi-cn'></i>";
                            break;
        
                    }
                break;
        
        
            }
            $calc = $amount*$convrate;
        
            echo "$flagog $currency $amount = $flagnew $currencyTo $calc";
                
        
        }else{
            echo "that is not a valid input";
        }
        ?>
        
        </h2>
</form>

        


</fieldset>

</body>
</html>