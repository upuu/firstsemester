<!DOCTYPE html>

<html lang="en">

<head>

<title>Welcome all!</title>

</head>

<body>





 <h1>If you want a custom greeting message, please do the following: </h1>
 <fieldset>
 <ol>
    <li>In your address bar, append a '?' symbol </li>
    <li>Then write 'firstName=' with your first name next to it</li>
    <li>Then write '&' followed by 'lastName' with your last name next to it</li>
    <li>Hit ENTER and see your customized message in the greeting below</li>
</ol>
</fieldset>
<h1> <?php 

if(isset($_GET["lastName"]) && isset($_GET["firstName"])){
    if($_GET["lastName"] == '' && $_GET["firstName"] == ''){
        echo 'Howdy no names!';
    }else{ echo 'howdy ' . $_GET["firstName"] . ' ' . $_GET["lastName"];} 
}
elseif(isset($_GET["lastName"])){
    echo "Howdy " . $_GET["lastName"];
}
elseif(isset($_GET["firstName"])) {
    echo "Howdy " . $_GET["firstName"] ;
}



?> 
</h1>

</body>
</html>