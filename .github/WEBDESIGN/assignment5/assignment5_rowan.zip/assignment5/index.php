<!DOCTYPE html>
<html lang="en">
<head>
<meta charset ="UTF-8">

<link 
    rel="stylesheet" 
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
/>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/gh/lipis/flag-icons@6.11.0/css/flag-icons.min.css"
/>

 <style>* {
    box-sizing: border-box;
   }
   #myInput {
    background-image: url('/css/searchicon.png');
    background-position: 10px 12px;
    background-repeat: no-repeat;
    width: 100%;
    font-size: 16px;
    padding: 12px 20px 12px 40px;
    border: 1px solid #ddd;
    margin-bottom: 12px;
   }
   #myUL {
    list-style-type: none;
    padding: 0;
    margin: 0;
   }
   #myUL li a {
    border: 1px solid #ddd;
    margin-top: -1px; /* Prevent double borders */
    background-color: #f6f6f6;
    padding: 0;
    text-decoration: none;
    font-size: 18px;
    color: black;
    display: block
   
   }
   #myUL li a:hover:not(.header) {
    background-color: #eee;
   }
   body {
  font-family: Arial, Helvetica, sans-serif;
}

.navbar {
  overflow: hidden;
  background-color: #333;
  width: 100%;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(146, 69, 182);
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #ffffff;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #8b878b;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.greeting {
  font-weight: bold;
  font: #ff0000e8;
}

</style>
   
<title>Home</title>
</head>


<body> 
    <div class="navbar">
        <a class="active" href="index.html"><i class="fa fa-fw fa-home"></i> Home</a> 
        <div class="dropdown">
            <button class="dropbtn"><i class="fa fa-fw fa-caret-down"></i>Products  
            </button>
            <div class="dropdown-content">
              <a href="currency.php">Currency Exchange</a>
              <a href="#">Service 2</a>
            </div>
        </div> 
        <div class="dropdown">
            <button class="dropbtn"><i class="fa fa-fw fa-caret-down"></i>Contact Us</button>
            <div class="dropdown-content">
                <a href="#"><i class="fi fi-fr"></i>Contactez-nous</a>
                <a href="#"><i class="fi fi-es"></i>Contacta con nosotras</a>
            </div>
        </div>
        <a class="active" href="aboutme.html">About</a>
      </div>
      <p> Welcome to my website, feel free to search for products and explore our site!</p>  
      <div class = greeting>
      <script>
        const date = new Date();
        const currentTime = date.getHours();
        
        let greeting;
        
        if (currentTime >= 6 && currentTime <= 12) {
          greeting = "<b>Good Morning, you must be an early bird!</b>";
        } else if (currentTime > 12 && currentTime <= 18) {
          greeting = "<b>Good Afternoon</b>";
        } else {
          greeting = "<b>Good Evening</b>";
        }
        p = document.createElement("p");
        p.innerHTML = greeting;
        document.body.appendChild(p).style.color = "#ff0000";
        </script>
      </div>
        
      <h2>My Phonebook</h2>
      <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." title="Type in a 
      name">
      <ul id="myUL" style="display: none;">
       <li><a href="#">Adele</a></li>
       <li><a href="#">Agnes</a></li>
       <li><a href="#">Billy</a></li>
       <li><a href="#">Bob</a></li>
       <li><a href="#">Calvin</a></li>
       <li><a href="#">Christina</a></li>
       <li><a href="#">Cindy</a></li>
       <li><a href="#">Cynthia</a></li>
       <li><a href="#">Candy</a></li>
       <li><a href="#">Coral</a></li>
       <li><a href="#">Callum</a></li>
       <li><a href="#">Corey</a></li>
       <li><a href="#">Cooper</a></li>
       <li><a href="#">Dave</a></li>
       <li><a href="#">Dallas</a></li>
       <li><a href="#">Darrow</a></li>
       <li><a href="#">Durger</a></li>
       <li><a href="#">Dentures</a></li>
       <li><a href="#">Detailed</a></li>
       <li><a href="#">Delicious</a></li>
       <li><a href="#">Destroyer</a></li>
       <li><a href="#">Donnie</a></li>
       <li><a href="#">Donald</a></li>
       <li><a href="#">Douglas</a></li>
       <li><a href="#">Dougie</a></li>
       <li><a href="#">Echo</a></li>
       <li><a href="#">Ekko</a></li>
       <li><a href="#">Ethan</a></li>
       <li><a href="#">Expert</a></li>
       <li><a href="#">Evan</a></li>
       <li><a href="#">Eberly</a></li>
       <li><a href="#">Everett</a></li>
       <li><a href="#">Entitled</a></li>
       <li><a href="#">Frank</a></li>
       <li><a href="#">Franklin</a></li>
       <li><a href="#">Forrest</a></li>
       <li><a href="#">Forager</a></li>
       <li><a href="#">Fanny</a></li>
       <li><a href="#">Ferb</a></li>
       <li><a href="#">Forgotten</a></li>
       <li><a href="#">Gelkin</a></li>
       <li><a href="#">Gotcha</a></li>
       <li><a href="#">Gorlock</a></li>
       <li><a href="#">Him</a></li>
       <li><a href="#">Himothy</a></li>
       <li><a href="#">Harold</a></li>
       <li><a href="#">Ivan</a></li>
       <li><a href="#">Isen</a></li>
       <li><a href="#">Isaac</a></li>
       <li><a href="#">Jake</a></li>
      </ul>
      <script>
      function myFunction() {
       var input, filter, ul, li, a, i, txtValue;
       input = document.getElementById("myInput");
       filter = input.value.toUpperCase();
       ul = document.getElementById("myUL");
       li = ul.getElementsByTagName("li"); 
  
       if(input.value.length == 0){
        ul.style.display = "none";
        return;
      }else{
        ul.style.display = "block";
       }
       for (i = 0; i < li.length; i++) {
       a = li[i].getElementsByTagName("a")[0];
       txtValue = a.textContent || a.innerText;
       if (txtValue.toUpperCase().indexOf(filter) > -1) {
       li[i].style.display = "";
       } else {
       li[i].style.display = "none";
       }
       }
      10
      }
      </script>
</body>
</html>
