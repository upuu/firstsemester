<!DOCTYPE html>
<html lang="en">
<head>
<meta charset ="UTF-8">

<link 
    rel="stylesheet" 
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
/>
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/gh/lipis/flag-icons@6.11.0/css/flag-icons.min.css"
/>

 <style>* {
    box-sizing: border-box;
   }
   #myInput {
    background-image: url('/css/searchicon.png');
    background-position: 10px 12px;
    background-repeat: no-repeat;
    width: 100%;
    font-size: 16px;
    padding: 12px 20px 12px 40px;
    border: 1px solid #ddd;
    margin-bottom: 12px;
   }
   #myUL {
    list-style-type: none;
    padding: 0;
    margin: 0;
   }
   #myUL li a {
    border: 1px solid #ddd;
    margin-top: -1px; /* Prevent double borders */
    background-color: #f6f6f6;
    padding: 0;
    text-decoration: none;
    font-size: 18px;
    color: black;
    display: block
   
   }
   #myUL li a:hover:not(.header) {
    background-color: #eee;
   }
   body {
  font-family: Arial, Helvetica, sans-serif;
}

.navbar {
  overflow: hidden;
  background-color: #333;
  width: 100%;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: rgb(146, 69, 182);
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #ffffff;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #8b878b;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.greeting {
  font-weight: bold;
  font: #ff0000e8;
}

</style>
<title>Home</title>
<?php include ('C:/xampp/htdocs/index/include/init.php'); ?>
</head>


<body> 
    <div class="navbar">
        <a class="active" href="index.html"><i class="fa fa-fw fa-home"></i> Home</a> 
        <div class="dropdown">
            <button class="dropbtn"><i class="fa fa-fw fa-caret-down"></i>Products  
            </button>
            <div class="dropdown-content">
              <a href="currency.php">Currency Exchange</a>
              <a href="#">Service 2</a>
            </div>
        </div> 
        <div class="dropdown">
            <button class="dropbtn"><i class="fa fa-fw fa-caret-down"></i>Contact Us</button>
            <div class="dropdown-content">
                <a href="#"><i class="fi fi-fr"></i>Contactez-nous</a>
                <a href="#"><i class="fi fi-es"></i>Contacta con nosotras</a>
            </div>
        </div>
        <a class="active" href="aboutme.html">About</a>
      </div>
      <p> Welcome to my website, feel free to search for products and explore our site!</p>  
      <div class = greeting>
      <script>
        const date = new Date();
        const currentTime = date.getHours();
        
        let greeting;
        
        if (currentTime >= 6 && currentTime <= 12) {
          greeting = "<b>Good Morning, you must be an early bird!</b>";
        } else if (currentTime > 12 && currentTime <= 18) {
          greeting = "<b>Good Afternoon</b>";
        } else {
          greeting = "<b>Good Evening</b>";
        }
        p = document.createElement("p");
        p.innerHTML = greeting;
        document.body.appendChild(p).style.color = "#ff0000";
        </script>
      </div>
        
      <h2>My Phonebook</h2>
      <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for item number" title="Type in a 
      name">
      
      <?php
      echo "<html><body><table id = 'myTable' style='display: none';>\n\n";
  
        // Get csv file 
        if(($handle = fopen("input.csv",  
                        "r")) !== FALSE) { 
            $n = 1; 
            while(($row = fgetcsv($handle))  
                                !== FALSE) { 
  
                // call the csv file, begin putting it inside of the table
                //  use the ignore keyword to ensure no primary keys are duplicated,
                // which will avoid errors if the query is run multiple times successfully
                $conn->query('INSERT IGNORE INTO Items  
                VALUES ("'.$row[0].'","'.$row[1].'", 
                "'.$row[2].'","'.$row[3].'","'.$row[4].'","'.$row[5].'")'); 
  
                if($n>1) { 
                ?> 
                <tr> 
                    <td> 
                        <center> 
                            <?php echo $row[0];?> 
                        </center> 
                    </td> 
                    <td> 
                        <center> 
                            <?php echo $row[1];?> 
                        </center> 
                    </td> 
                    <td> 
                        <center> 
                            <?php echo $row[2];?> 
                        </center> 
                    </td> 
                    <td> 
                        <center>
                            <?php echo $row[3]; ?>
                        </center>
                    </td>
                    <td>
                        <center>
                            <?php echo $row[4];?>
                        </center>
                    </td>
                    <td> 
                        <center> 
                            <?php echo $row[5];?> 
                        </center> 
                    </td> 
                </tr> 
                    <?php 
                } 
              
                // Increment records 
                $n++; 
            } 
              
        // Closing the file and the connection to the database 
        fclose($handle); 
        $conn->close();
    } 
    ?> 
    </body> 
</table>
<script>
      
      
      function myFunction() { //function used to seek through table
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
 
  if(input.value.length == 0){
        table.style.display = "none";
        return;
      }else{
        table.style.display = "block";
       }
 
  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
  </script>  
      
 
      
</body>
</html>
