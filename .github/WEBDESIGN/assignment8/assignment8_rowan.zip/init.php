<?php 
 $servername = 'localhost';
 $username = 'root';
 $password = "password";
 // create connection
 $conn = new mysqli($servername, $username,);

 if ($conn->connect_error) {
    die("Connection failed: ". $conn->connect_error);
 }
// create DB if it does not yet exist
$db_exists = mysqli_select_db($conn, 'assignment8');
if (!$db_exists) {
$sql = "CREATE DATABASE assignment8";
if ($conn->query($sql) === TRUE) {
echo "Database created successfully";
}else{
    echo "Error creating database." . $conn->error;
}
}

//add table if it doesnt yet exist,
mysqli_select_db($conn, "assignment8");
$sql2 = "CREATE TABLE IF NOT EXISTS Items (
    ID INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(40) NOT NULL,
    Type VARCHAR(40),
    Make VARCHAR(40),
    Model VARCHAR(40),
    Brand VARCHAR(40)
)";
if ($conn->query($sql2) === TRUE) {
    
}else{
    echo 'Error creating table: '. $conn->error;
}




?>